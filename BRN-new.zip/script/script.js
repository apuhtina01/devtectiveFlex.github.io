function openSubmenu() {
  var submenu = document.querySelector('.submenu');
  submenu.classList.add('open'); // Добавляем класс для открытия блока
}

function closeSubmenu() {
  var submenu = document.querySelector('.submenu');
  submenu.classList.remove('open'); // Удаляем класс для закрытия блока
}
